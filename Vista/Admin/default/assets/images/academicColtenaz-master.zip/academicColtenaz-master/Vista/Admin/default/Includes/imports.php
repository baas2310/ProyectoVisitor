<!-- IMPORTS HEAD -->

<!-- App favicon -->
<link rel="shortcut icon" href="assets/images/LogoColtenaz18.ico">

<!-- C3 charts css -->
<link href="../plugins/c3/c3.min.css" rel="stylesheet" type="text/css"  />

<!-- App css -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="assets/css/metismenu.min.css" rel="stylesheet" type="text/css" />
<link href="assets/css/style.css" rel="stylesheet" type="text/css" />

<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/modernizr.min.js"></script>

<!-- DataTables -->
<link href="../plugins/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="../plugins/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<!-- Responsive datatable examples -->
<link href="../plugins/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />

<!-- Plugin Css-->
<link rel="stylesheet" href="../plugins/magnific-popup/css/magnific-popup.css" />
<link rel="stylesheet" href="../plugins/jquery-datatables-editable/dataTables.bootstrap4.min.css" />

<!-- Sweet Alert -->
<link href="../plugins/sweet-alert2/sweetalert2.min.css" rel="stylesheet" type="text/css">

<!-- END IMPORTS HEAD -->